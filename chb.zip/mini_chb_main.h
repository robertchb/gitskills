#ifndef MINI_CHB_MAIN_H__
#define MINI_CHB_MAIN_H__
VOID Mini_CHB_TaskEntry(ULONG ulArg0, ULONG ulArg1, ULONG ulArg2, ULONG ulArg3);
ULONG MINI_CHB_RegApp();
VOID Mini_CHB_RPC_CallBack(ULONG ulSrcNode, ULONG ulSrcModuleID, VOID *pReceiveData,
                    ULONG ulReceiveDataLen, VOID **ppSendData, ULONG *pulSendDataLen);
ULONG Mini_CHB_IpcProc(VOID *pMsg);
VOID Mini_CHB_LpuSmoothSync();
VOS_VOID * VOS_memcpy_s( VOS_VOID *pvDest, VOS_SIZE_T uvDestSize, const VOS_VOID * pvSrc, VOS_SIZE_T uvCount );
ULONG SYS_RegAppInfo(APP_INIT_INFO_S *pstAppInfo);
#endif

