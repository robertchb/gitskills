/******************************************************************************

                  ��Ȩ���� (C), 2001-2011, ��Ϊ�������޹�˾

 ******************************************************************************
  �� �� ��   : mini_chb_cfg.c
  �� �� ��   : ����
  ��    ��   : �Ժ��� 00502260
  ��������   : 2019��5��14��
  ����޸�   :
  ��������   : minitask�����еĴ�������
  �����б�   :
             
  �޸���ʷ   :
  1.��    ��   : 2019��5��14��
    ��    ��   : �Ժ��� 00502260
    �޸�����   : �����ļ�

******************************************************************************/
#ifndef __MINI_CHB_CFG_H__
#define __MINI_CHB_CFG_H__




typedef struct ST_MINI_CHB_MSGHEAD
{
    ULONG ulMsgCode;     /* ��Ϣ�� */
    ULONG ulParas[4];    /* ��ദ��4����Ϣ�� */
    ULONG ulLength;      /* ��Ϣ���ݵĳ��ȣ���������Ϣͷ�� */
}MINI_CHB_MSGHEAD;


ULONG Mini_CHB_CmdDisGetParas(VOID *pMsgRcv, ULONG *pulIdx1, ULONG *pulIdx2, ULONG *pulAll, ULONG *pulSlot);

ULONG Mini_CHB_CmdSetGetParas(VOID *pMsgRcv, ULONG *pulIdx1, ULONG *pulIdx2, ULONG *pulVal, ULONG *pulAll, ULONG *pulSlot, ULONG *pulUndo);

extern ULONG Mini_CHB_CmdSetProc(VOID *pMsgRcv);

extern ULONG Mini_CHB_CmdDisProc(VOID *pMsgRcv);

extern ULONG MINI_CHB_GetSelfBoardID();

extern ULONG MINI_CHB_IsBoardRegisted(ULONG ulSlotID);

extern ULONG MINI_CHB_IsSlaveReady();

extern VOS_INT LSW_sprintf_s(VOS_CHAR* strDest, VOS_SIZE_T destMax, const VOS_CHAR* format, ...);

extern ULONG Mini_CHB_SendCmd(ULONG ulSlot, MINI_CHB_MSGHEAD * pstMsg);

extern ULONG Mini_CHB_DealRpcRcv(MINI_CHB_MSGHEAD * pstMsg);

extern ULONG Mini_CHB_CmdSetValue(ULONG ulAll, ULONG pulIdx1, ULONG pulIdx2, ULONG ulValue);

extern ULONG Mini_CHB_LpuDispValues(MINI_CHB_MSGHEAD *pstMsg, CHAR *pOut);

extern ULONG Mini_CHB_LpuCmdDispatch(MINI_CHB_MSGHEAD *pstMsg, CHAR ** pOut);

extern ULONG MINI_CHB_GetMaxLpuID();

extern LONG Mini_CHB_DebugAll();

extern LONG Mini_CHB_NoDebugAll();

extern LONG Mini_CHB_ShowDebugging(CHAR *szBuf, ULONG ulMaxLen, ULONG ulIfIndex, ULONG *pulWaitlistHandle, ULONG ulInterface);

extern ULONG Mini_CHB_CmdDebugProc(VOID *pMsgRcv);

extern ULONG MINI_CHB_GetMasterID();

extern CHAR *Mini_CHB_GetExecString(ULONG ulExecId, ULONG ulExecInfo);

extern VOID Mini_CHB_ExecInfo(ULONG ulExecId, CHAR *pszExp, ...);

extern VOID Mini_CHB_DbgOutput(ULONG ulDebug, CHAR *szExp, ...);

extern ULONG Mini_CHB_CmdDebugGetParas(VOID *pMsgRcv, ULONG *pulUndo, ULONG *pulInfo, ULONG *pulError, ULONG *pulEvent, ULONG *pulSlot);
    
extern ULONG Mini_CHB_TrapValueDiff(ULONG ulSlot, ULONG ulIndex1, ULONG ulIndex2);

extern ULONG Mini_CHB_LogAllValueChange(ULONG ulslot, ULONG ulValue);

extern ULONG Mini_CHB_LogValueChange(ULONG ulIndex1, ULONG ulIndex2, ULONG ulslot, ULONG ulValue);

extern VOID Mini_CHB_RealTimeBackSend();

extern VOS_UINT32 VOS_StrLen( VOS_CHAR * pscStr );

extern VOS_INT32 VOS_nvsprintf(VOS_CHAR * pscOBuf,VOS_UINT32 ulMaxStrLen, const VOS_CHAR * format, va_list arg_pt);

#endif
