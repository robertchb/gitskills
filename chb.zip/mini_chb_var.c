/******************************************************************************

                  ��Ȩ���� (C), 2001-2011, ��Ϊ�������޹�˾

 ******************************************************************************
  �� �� ��   : mini_chb_var.c
  �� �� ��   : ����
  ��    ��   : �Ժ���(c00502260)
  ��������   : 2019��5��5��
  ����޸�   :
  ��������   : ģ���������
  �����б�   :
  �޸���ʷ   :
  1.��    ��   : 
    ��    ��   : �Ժ���(c00502260)
    �޸�����   : 

******************************************************************************/

#include "vrpcfg.h"

#if (VRP_OS_LINUX == VRP_YES)
    #include "product/BSP/bsp/common/secure_c/securec.h"
#else
    #include "product/BSP/bsp/common/secure_c/securec.h"
#endif

#include "vos/vospubh/basetype.h"
#include "vos/vospubh/vos_def.h"
#include "vos/vospubh/vos_task.h"
#include "vos/vospubh/vos_que.h"
#include "vos/vospubh/vos_intr.h"
#include "vos/vospubh/vos_tmr.h"
#include "vos/vospubh/vos_time.h"
#include "vos/vospubh/vos_ker.h"
#include "vos/vosprih/vos_kerx.h"
#include "vos/vospubh/vos_util.h"
#include "vos/vospubh/vos_mem.h"
#include "vos/vospubh/vos_id.h"
#include "vos/vospubh/ipc_inc.h"
#include "vos/vospubh/rpc_inc.h"
#include "vos/vospubh/vos_err.h"
#include "vos/vospubh/vos_ev.h"
#include "vos/vospubh/vos_arg.h"

#include "dopra/vos/include/vos_def.h"
#include "dopra/vos/include/v_typdef.h"
#include "dopra/vos/include/dopra/osal/osal_time.h"
#include "dopra/vos/include/v_systime.h"
#include "dopra/vos/include/v_queue.h"
#include "dopra/vos/include/v_event.h"
#include "dopra/vos/include/v_cputick.h"
#include "dopra/target/include/v_task.h"
#include "dopra/target/include/v_vfs.h"
//#include "dopra/dopra3.1/dopra/target/include/securec.h"


#include "iroot.h"
#include "product/switch/include/hpi/srm_pub.h"

#include "product/switch/source/mini_task_2019/chb/mini_chb_var.h"
#include "product/switch/source/mini_task_2019/chb/mini_chb_def.h"


ULONG g_ulMiniTaskId_CHB = 0;         //����ID��ȫ�ֱ���
ULONG g_ulMiniQueId_CHB = 0;          /* MiniTask��Ϣ����ID */  

ULONG g_aulMiniData_chb[MINI_CHB_DATA_ROW][MINI_CHB_DATA_COL] = {{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},
                                                                {0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0},
                                                                {0,0,0,0,0,0,0,0,0,0},{0,0,0,0,0,0,0,0,0,0}}; //����ȫ�����鲢��ʼ��


ULONG g_ulMiniDebug_info_chb  =0;           /* Miniģ��ĵ��Կ��� */
ULONG g_ulMiniDebug_error_chb  =0;           /* Miniģ��ĵ��Կ��� */
ULONG g_ulMiniDebug_event_chb  =0;           /* Miniģ��ĵ��Կ��� */

MINI_CHB_DEBUG_S g_stMiniDebug_CHB = {MINI_CHB_DEBUG_OFF, MINI_CHB_DEBUG_OFF, MINI_CHB_DEBUG_OFF};   /* debug���� */

#if  (VRP_MAIN_BOARD == VRP_YES)
ULONG g_ulMiniInforIndex_chb = 0;       /* �õ���Ϣ��ȫ�������е����� */
#endif /* #if (VRP_MAIN_BOARD == VRP_YES) */

/* VRPv5 ����ע��Ľṹ�� */
APP_INIT_INFO_S g_stMiniAppInfo_CHB = 
{
    MID_MINI_CHB,                                  /* ulMID,ģ��ID��*/
    "CHB",                                         /* szAppName[APP_NAME_MAX_LEN + 1] */
    NULL,                                         /* pstComponentInfo */
    Mini_CHB_TaskEntry,                            /* pfTaskEntry */
    "CHB",                                         /* szTaskName[APP_TASK_NAME_LEN + 1] */
    VOS_T_PRIORITY_NORMAL,                        /* ulTaskPriority ,�������ȼ�*/
    0,                                            /* ulTaskMode */
    0,                                            /* ulTaskStackSize */
    {0,0,0,0},                                    /* ulTaskArg[APP_TASK_PARA_NUM] */
    NULL,                                         /* pfAppInit */
    NULL,                                         /* pfMibReg */
    NULL,                                         /* pfIfnetHotNotifyCB */
    NULL,                                         /* pfCfaCB */
    NULL,                                         /* ppcExecInfor_EN */
    NULL,                                         /* ppcExecInfor_CN */
    NULL,                                         /* ppcExecInfor_EXTD */
    0,                                            /* ulAppIndex */
    0,                                            /* ulTaskId */
    0                                             /* ulExecInforIndex */
};


